Install pytube:
`$ pip install pytube -t`

Zip dir:
`$ zip -r yt.zip .`
